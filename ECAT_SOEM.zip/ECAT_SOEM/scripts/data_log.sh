#!/bin/bash

cd ../result_data/lcm_log
#lcm-logger ./data$(date +%F).lcm
lcm-logger ./data.lcm
