#!/bin/bash
./../scripts/log_convert.sh lcm_log/data_leg1_c.lcm matlab_log/data_leg1_c.mat







